// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("soname check\n", stdout);
  return lionss_run_workload("soname-check");
}
