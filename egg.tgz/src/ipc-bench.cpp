// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("ipc bench\n", stdout);
  return lionss_run_workload("ipc-bench");
}
