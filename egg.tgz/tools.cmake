# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(soname-check src/soname-check.cpp)
set_property(TARGET soname-check PROPERTY CXX_STANDARD 11)
target_link_libraries(soname-check lionss pthread)

add_executable(split-dwarf src/split-dwarf.cpp)
set_property(TARGET split-dwarf PROPERTY CXX_STANDARD 11)
target_link_libraries(split-dwarf lionss pthread)

add_executable(grype-scan src/grype-scan.cpp)
set_property(TARGET grype-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(grype-scan lionss pthread)

add_executable(vendored-check src/vendored-check.cpp)
set_property(TARGET vendored-check PROPERTY CXX_STANDARD 11)
target_link_libraries(vendored-check lionss pthread)

add_executable(build-header-only src/build-header-only.cpp)
set_property(TARGET build-header-only PROPERTY CXX_STANDARD 11)
target_link_libraries(build-header-only lionss pthread)

add_executable(ninja-build src/ninja-build.cpp)
set_property(TARGET ninja-build PROPERTY CXX_STANDARD 11)
target_link_libraries(ninja-build lionss pthread)

add_executable(property-tests src/property-tests.cpp)
set_property(TARGET property-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(property-tests lionss pthread)

add_executable(jumbo-build src/jumbo-build.cpp)
set_property(TARGET jumbo-build PROPERTY CXX_STANDARD 11)
target_link_libraries(jumbo-build lionss pthread)

add_executable(mutmut-run src/mutmut-run.cpp)
set_property(TARGET mutmut-run PROPERTY CXX_STANDARD 11)
target_link_libraries(mutmut-run lionss pthread)

add_executable(duplication-check src/duplication-check.cpp)
set_property(TARGET duplication-check PROPERTY CXX_STANDARD 11)
target_link_libraries(duplication-check lionss pthread)

add_executable(flamegraph src/flamegraph.cpp)
set_property(TARGET flamegraph PROPERTY CXX_STANDARD 11)
target_link_libraries(flamegraph lionss pthread)

add_executable(uclibc-build src/uclibc-build.cpp)
set_property(TARGET uclibc-build PROPERTY CXX_STANDARD 11)
target_link_libraries(uclibc-build lionss pthread)

add_executable(ipc-bench src/ipc-bench.cpp)
set_property(TARGET ipc-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(ipc-bench lionss pthread)

add_executable(rpath-check src/rpath-check.cpp)
set_property(TARGET rpath-check PROPERTY CXX_STANDARD 11)
target_link_libraries(rpath-check lionss pthread)

add_executable(wheel-build src/wheel-build.cpp)
set_property(TARGET wheel-build PROPERTY CXX_STANDARD 11)
target_link_libraries(wheel-build lionss pthread)

add_executable(maintainability-index src/maintainability-index.cpp)
set_property(TARGET maintainability-index PROPERTY CXX_STANDARD 11)
target_link_libraries(maintainability-index lionss pthread)

add_executable(callgrind-profile src/callgrind-profile.cpp)
set_property(TARGET callgrind-profile PROPERTY CXX_STANDARD 11)
target_link_libraries(callgrind-profile lionss pthread)

add_executable(weekly-build src/weekly-build.cpp)
set_property(TARGET weekly-build PROPERTY CXX_STANDARD 11)
target_link_libraries(weekly-build lionss pthread)

add_executable(reuse-lint src/reuse-lint.cpp)
set_property(TARGET reuse-lint PROPERTY CXX_STANDARD 11)
target_link_libraries(reuse-lint lionss pthread)

add_executable(ios-arm64 src/ios-arm64.cpp)
set_property(TARGET ios-arm64 PROPERTY CXX_STANDARD 11)
target_link_libraries(ios-arm64 lionss pthread)

add_executable(gcov-report src/gcov-report.cpp)
set_property(TARGET gcov-report PROPERTY CXX_STANDARD 11)
target_link_libraries(gcov-report lionss pthread)

add_executable(throughput-bench src/throughput-bench.cpp)
set_property(TARGET throughput-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(throughput-bench lionss pthread)

add_executable(encoding-tests src/encoding-tests.cpp)
set_property(TARGET encoding-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(encoding-tests lionss pthread)

add_executable(gcc-13 src/gcc-13.cpp)
set_property(TARGET gcc-13 PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-13 lionss pthread)

add_executable(build-no-exceptions src/build-no-exceptions.cpp)
set_property(TARGET build-no-exceptions PROPERTY CXX_STANDARD 11)
target_link_libraries(build-no-exceptions lionss pthread)

add_executable(cve-check src/cve-check.cpp)
set_property(TARGET cve-check PROPERTY CXX_STANDARD 11)
target_link_libraries(cve-check lionss pthread)

add_executable(markdown-lint src/markdown-lint.cpp)
set_property(TARGET markdown-lint PROPERTY CXX_STANDARD 11)
target_link_libraries(markdown-lint lionss pthread)

add_executable(license-headers src/license-headers.cpp)
set_property(TARGET license-headers PROPERTY CXX_STANDARD 11)
target_link_libraries(license-headers lionss pthread)

add_executable(cyclonedx-sbom src/cyclonedx-sbom.cpp)
set_property(TARGET cyclonedx-sbom PROPERTY CXX_STANDARD 11)
target_link_libraries(cyclonedx-sbom lionss pthread)

add_executable(trufflehog src/trufflehog.cpp)
set_property(TARGET trufflehog PROPERTY CXX_STANDARD 11)
target_link_libraries(trufflehog lionss pthread)

